
function out = sigmoid(X,a,b)
 out = a.*(exp(b.*X)-exp(-b.*X));
 out = out./(exp(b.*X)+exp(-b.*X));
end