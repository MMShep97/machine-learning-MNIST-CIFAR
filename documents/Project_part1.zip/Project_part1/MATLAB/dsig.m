
function out = dsig(X,a,b)
 out = a*b*sech(X).^2;
end